# Changelog

## 0.2.0

- Add typed configuration and pipeline middleware.
- Add request id and user agent interceptors.

## 0.1.0

- Initial release.

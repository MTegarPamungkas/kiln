# Changelog

## 0.1.0

- AuthRepository, SocialAuth, AccountManagement, dan TokenProvider di atas
  Firebase Auth lewat gateway yang bisa di-fake.
- Firestore RemoteDatabase dengan mapper RemoteQuery, penolakan kombinasi
  indeks komposit, dan watch realtime.
- Cloud Storage FileStorage dengan progress unggah.
- Session bridge ke SessionController, setup emulator flavor development,
  konfigurasi bertipe, hook peringatan FlutterFire, serta dokumentasi setup.

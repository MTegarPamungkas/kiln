# riverpod

Kiln state management based on `flutter_riverpod`.

This extension is exclusive in the `state` category, provides `state_riverpod`, and
adds `ProviderScope` through the `app.wrappers` slot. The Registry is overridden to
providers, so features can read contracts with:

```dart
final client = ref.watch(kilnProvider<HttpClient>());
```

Brick contents:

- `kiln_providers.dart` — `registryProvider` and `kilnProvider<T>()`.
- `provider_overrides.dart` — `testProviderContainer` with the Registry overridden.
- `async_value_x.dart` — concise failure/data access.
- `session_notifier.dart` — wraps `SessionController`.
- `app_provider_observer.dart` — provider updates and failures to the `AppLogger`.
- `features/notes/` — a clean-architecture sample feature: `domain/` and
  `data/`, byte-identical to the `bloc` brick, plus `presentation/providers/`,
  `screens/`, and `widgets/`.

## Gate

State management has no request/response verbs. The extension registers
`RiverpodSupport`; providers live in feature code, which owns the UI.

## Runtime support

This extension reports platform and device readiness through `SupportRegistry`.
Unsupported calls return typed information instead of blocking startup. See
[support and devices](../../docs/extensions/support-and-devices.md) for the
probe and possible states.

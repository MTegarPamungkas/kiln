# Changelog

## 0.1.0

- Add `LocationProvider`, the geolocator gateway, permission-aware reads and
  streams, Android/iOS/macOS native setup, and runtime support reporting.

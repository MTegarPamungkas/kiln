# dio

HTTP client for Kiln built on `dio`.

The extension provides the `http_client` and `http_pipeline` capabilities and
opens the `http.interceptors` slot. Other extensions contribute
`HttpMiddleware` instead of importing dio.

```bash
kiln add dio --answer base_url=https://api.example.com
```

Application code reads the contract, never the implementation:

```dart
final client = RegistryScope.read<HttpClient>(context);
final response = await client.get(Uri.parse('https://api.example.com/users'));
```

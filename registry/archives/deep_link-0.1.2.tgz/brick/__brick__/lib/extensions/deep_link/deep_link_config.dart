/// Settings for incoming and outgoing deep links.
final class DeepLinkConfig {
  const DeepLinkConfig({
    this.scheme = 'kiln',
    this.allowedHosts = const <String>[],
    this.customSchemeHosts = const <String>[],
    this.pathPrefixes = const <String>[],
    this.stripTrackingParameters = true,
    this.trackingParameters = defaultTrackingParameters,
    this.dropFragment = true,
    this.deduplicationWindow = const Duration(seconds: 2),
  });

  /// Settings rendered from the install prompts.
  static const defaults = DeepLinkConfig(
    scheme: '{{scheme}}',
    allowedHosts: <String>[
{{#hosts}}      '{{{.}}}',
{{/hosts}}    ],
    pathPrefixes: <String>[
{{#path_prefixes}}      '{{{.}}}',
{{/path_prefixes}}    ],
  );

  /// Query parameters removed by the link normalizer unless disabled.
  static const Set<String> defaultTrackingParameters = <String>{
    'fbclid',
    'gclid',
    'igshid',
    'mc_cid',
    'mc_eid',
    'utm_campaign',
    'utm_content',
    'utm_medium',
    'utm_source',
    'utm_term',
  };

  /// Custom scheme that opens the app, for example `kiln`.
  final String scheme;

  /// Hosts accepted for `https` app links.
  ///
  /// An empty list rejects every web link; the custom scheme keeps working.
  final List<String> allowedHosts;

  /// Optional host allowlist for custom schemes. The host is usually the first
  /// route segment (`kiln://orders/42` routes to `/orders/42`), not a web domain.
  /// An empty list accepts any custom host; [pathPrefixes] still apply.
  final List<String> customSchemeHosts;

  /// Route path prefixes accepted for HTTPS and custom-scheme links.
  /// Custom links include their host as the first route segment.
  ///
  /// An empty list accepts every path on the allowed hosts.
  final List<String> pathPrefixes;

  /// Whether tracking query parameters are dropped while normalizing.
  final bool stripTrackingParameters;

  /// Query parameters considered tracking when [stripTrackingParameters].
  final Set<String> trackingParameters;

  /// Whether fragments are removed while normalizing.
  final bool dropFragment;

  /// How long the same link is ignored after it was last accepted.
  final Duration deduplicationWindow;

  /// The scheme without separators or casing.
  String get schemeName {
    final value = scheme.trim().toLowerCase();
    final separator = value.indexOf('://');
    final withoutSuffix = separator < 0 ? value : value.substring(0, separator);
    return withoutSuffix.replaceAll(':', '');
  }

  /// Whether `https` app links are accepted at all.
  bool get allowsUniversalLinks => allowedHosts.isNotEmpty;

  /// Whether incoming route paths must match a configured prefix.
  bool get restrictsPaths => pathPrefixes.isNotEmpty;
}

# Changelog

## 0.1.0

- Add `ShareService`, the share_plus gateway, runtime support reporting, and
  platform declarations.

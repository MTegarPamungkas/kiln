import 'package:flutter_test/flutter_test.dart';
import 'package:kiln_core/kiln_core.dart';
import 'package:kiln_testing/kiln_testing.dart';
import 'package:{{app_name}}/app/app_wrappers.dart';
import 'package:{{app_name}}/extensions/riverpod/riverpod_module.dart';
import 'package:{{app_name}}/extensions/riverpod/riverpod_support.dart';

void main() {
  test('declares the optional dependency that determines readiness', () {
    expect(const RiverpodModule().optionalRequires, contains('logger'));
  });

  test('module registers the app wrapper', () {
    final registry = createTestRegistry();

    const RiverpodModule().register(registry);

    final slot = registry.read<SlotRegistry>().find<AppWrapper>(
      SlotNames.appWrappers,
    );
    expect(slot, isNotNull);
    expect(slot!.items, hasLength(1));
    expect(registry.read<RiverpodSupport>(), isA<RiverpodSupport>());
  });
}

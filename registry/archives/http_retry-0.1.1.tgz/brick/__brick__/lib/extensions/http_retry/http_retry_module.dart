import 'package:kiln_core/kiln_core.dart';

import 'http_retry_support.dart';
import 'retry_budget.dart';
import 'retry_events.dart';
import 'retry_middleware.dart';
import 'retry_settings.dart';

/// Adds the retry middleware to the registered HTTP pipeline.
///
/// When the application registers a [RetryEvents] before bootstrap, the module
/// wires it into the middleware so retries and give-ups can be observed.
final class HttpRetryModule extends KilnModule {
  const HttpRetryModule({this.settings = HttpRetrySettings.defaults});

  /// Retry settings; override to add a [HttpRetrySettings.totalBudget] or a
  /// different attempt policy.
  final HttpRetrySettings settings;

  @override
  String get id => 'http_retry';

  @override
  Set<String> get requires => const <String>{'http_client', 'http_pipeline'};

  @override
  void register(Registry registry) {
    final pipeline = registry.read<HttpPipeline>();
    pipeline.use(
      RetryMiddleware(
        settings: settings,
        budget: RetryBudget(clock: registry.readOrNull<Clock>()),
        events: registry.readOrNull<RetryEvents>(),
        clock: registry.readOrNull<Clock>() ?? const SystemClock(),
      ),
      priority: 20,
    );
    registry.registerSingleton<HttpRetrySupport>(
      HttpRetrySupport(settings: settings),
    );
  }

  @override
  SupportInfo support(Registry registry) {
    return registry.read<HttpRetrySupport>().info;
  }
}

# Changelog

## 0.1.0

- Initial biometric facade, availability, gate, app lock, lock scope, and
  protected secure storage.

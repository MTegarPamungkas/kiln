# Changelog

## 0.1.0

- Initial Appwrite auth, account management, session bridge, query mapping,
  remote database, realtime gateway, and file storage.

# Changelog

## 0.1.0

- Initial deep link support: gateway `app_links`, allowlist, normalizer,
  deduplicator, pending link buffer, outgoing link builder, module, and tests.

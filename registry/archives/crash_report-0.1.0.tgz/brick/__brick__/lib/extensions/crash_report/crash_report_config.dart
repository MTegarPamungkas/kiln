import 'package:kiln_core/kiln_core.dart';

/// Settings for the Sentry-backed crash reporter.
///
/// The DSN and release are rendered from the install prompts. Never put the DSN
/// in a log line or a reported event; [toString] masks it on purpose.
final class CrashReportConfig {
  CrashReportConfig({
    this.dsn = '{{dsn}}',
    this.release = '{{release}}',
    this.environment,
    this.sampleRate = 1.0,
    Set<AppFlavor>? enabledFlavors,
    this.noopWhenDsnEmpty = true,
    this.sendDefaultPii = false,
  }) : enabledFlavors = Set<AppFlavor>.unmodifiable(
         enabledFlavors ?? defaultEnabledFlavors,
       );

  /// Flavors allowed to send reports unless the application narrows the set.
  static final Set<AppFlavor> defaultEnabledFlavors = <AppFlavor>{
    AppFlavor.development,
    AppFlavor.staging,
    AppFlavor.production,
  };

  /// Values the Kiln installer writes into the application.
  static final CrashReportConfig defaults = CrashReportConfig();

  /// Sentry project DSN. An empty DSN disables reporting by default.
  final String dsn;

  /// Optional release string used to group errors in Sentry.
  final String release;

  /// Explicit environment override; when null the flavor name is used.
  final String? environment;

  /// Fraction of events to actually send, from 0.0 to 1.0.
  final double sampleRate;

  /// Flavors whose reports are allowed to leave the device.
  final Set<AppFlavor> enabledFlavors;

  /// Whether an empty [dsn] turns the extension into a no-op reporter.
  final bool noopWhenDsnEmpty;

  /// Whether Sentry may attach device identifiers as personal data.
  final bool sendDefaultPii;

  bool get hasDsn => dsn.trim().isNotEmpty;

  /// Whether this configuration intentionally reports nothing.
  bool get isNoop => noopWhenDsnEmpty && !hasDsn;

  /// The environment Sentry should tag reports with for [flavor].
  String environmentFor(AppFlavor? flavor) {
    final override = environment;
    if (override != null && override.trim().isNotEmpty) {
      return override;
    }
    return flavor?.name ?? 'production';
  }

  /// Whether [flavor] is allowed to send reports.
  bool isFlavorEnabled(AppFlavor? flavor) {
    if (enabledFlavors.isEmpty) {
      return false;
    }
    if (flavor == null) {
      return true;
    }
    return enabledFlavors.contains(flavor);
  }

  /// Whether the reporter talks to Sentry in [flavor].
  bool isActiveFor(AppFlavor? flavor) => !isNoop && isFlavorEnabled(flavor);

  /// Rejects values the Sentry SDK cannot be configured with.
  void validate() {
    final trimmed = dsn.trim();
    if (trimmed.isNotEmpty) {
      final uri = Uri.tryParse(trimmed);
      if (uri == null ||
          (uri.scheme != 'http' && uri.scheme != 'https') ||
          uri.host.isEmpty) {
        throw Failure(
          code: FailureCode.configurationInvalid,
          message: 'Crash report DSN is not an absolute HTTP(S) URL.',
          kind: FailureKind.configuration,
          details: <String, Object?>{'dsn': '[masked]'},
        );
      }
    }
    if (sampleRate < 0.0 || sampleRate > 1.0) {
      throw const Failure(
        code: FailureCode.configurationInvalid,
        message: 'Crash report sample rate must be between 0.0 and 1.0.',
        kind: FailureKind.configuration,
      );
    }
    if (!noopWhenDsnEmpty && !hasDsn) {
      throw const Failure(
        code: FailureCode.configurationMissing,
        message: 'A Sentry DSN is required when the empty-DSN noop is off.',
        kind: FailureKind.configuration,
      );
    }
  }

  CrashReportConfig copyWith({
    String? dsn,
    String? release,
    String? environment,
    double? sampleRate,
    Set<AppFlavor>? enabledFlavors,
    bool? noopWhenDsnEmpty,
    bool? sendDefaultPii,
  }) {
    return CrashReportConfig(
      dsn: dsn ?? this.dsn,
      release: release ?? this.release,
      environment: environment ?? this.environment,
      sampleRate: sampleRate ?? this.sampleRate,
      enabledFlavors: enabledFlavors ?? this.enabledFlavors,
      noopWhenDsnEmpty: noopWhenDsnEmpty ?? this.noopWhenDsnEmpty,
      sendDefaultPii: sendDefaultPii ?? this.sendDefaultPii,
    );
  }

  @override
  String toString() =>
      'CrashReportConfig(dsn: ${hasDsn ? '[set]' : '[empty]'}, '
      'environment: $environment, sampleRate: $sampleRate, '
      'enabledFlavors: ${enabledFlavors.map((flavor) => flavor.name).join(',')}, '
      'isNoop: $isNoop)';
}

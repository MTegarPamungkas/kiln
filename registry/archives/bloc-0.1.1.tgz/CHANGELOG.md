# Changelog

## 0.1.1

- The app wrapper now provides `CounterCubit`, so the generated counter example
  can read it from the widget tree.

## 0.1.0

- Initial Bloc/Cubit foundation, session cubit, async cubit, observer, and
  counter example.

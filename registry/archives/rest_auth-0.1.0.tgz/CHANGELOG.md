# Changelog

## 0.1.0

- Initial REST AuthRepository, token store, single-flight refresh, JWT expiry,
  middleware, unauthorized handling, account management, and session bridge.

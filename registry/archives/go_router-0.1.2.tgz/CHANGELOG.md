# Changelog

## 0.1.2

- Update `go_router` dependency constraint to `^18.1.4`.

## 0.1.1

- Import package:material_ui instead of the package:flutter/material.dart entry point, which Flutter 3.50 deprecated.

## 0.1.0

- Follow optional PushNotificationOpens taps alongside local notification taps.
  Push routes use the same route mapping and authentication redirects.
- Distinguish session restoration from signed-out state. Hide protected pages
  while restoring and preserve validated local return destinations through login.

- Initial release.

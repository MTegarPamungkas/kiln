import 'package:flutter/services.dart' show MissingPluginException;
import 'package:kiln_core/kiln_core.dart';

import 'analytics_config.dart';

typedef AnalyticsSetupProbe = Future<void> Function();

/// Reports whether analytics can send events for the current configuration.
final class AnalyticsSupport {
  AnalyticsSupport({
    required this.config,
    required this.flavor,
    required this.probe,
    this.isAllowed,
  });

  final AnalyticsConfig config;
  final AppFlavor? flavor;
  final AnalyticsSetupProbe probe;

  /// Reports whether analytics consent currently allows the SDK to start.
  final bool Function()? isAllowed;
  SupportInfo? _last;

  Future<SupportInfo> check() async {
    final last = _last;
    if (last != null) {
      return last;
    }
    final info = await _probe();
    _last = info;
    return info;
  }

  void clear() => _last = null;

  Future<SupportInfo> _probe() async {
    try {
      config.validate();
    } on Failure catch (failure) {
      return SupportInfo.unsupported(
        SupportState.notConfigured,
        message: failure.message,
        details: <String, Object?>{'code': failure.code.value},
      );
    }
    if (!config.isActiveFor(flavor)) {
      return SupportInfo.unsupported(
        SupportState.notConfigured,
        message: config.isNoop
            ? 'Analytics is disabled because the API key is empty.'
            : 'Analytics is disabled for this flavor.',
        details: <String, Object?>{
          'noop': config.isNoop,
          'flavor': flavor?.name,
        },
      );
    }
    if (!(isAllowed?.call() ?? true)) {
      return SupportInfo.unsupported(
        SupportState.notConfigured,
        message: 'Analytics starts after analytics consent is granted.',
        details: <String, Object?>{
          'consent': false,
          'host': config.host,
          'flavor': flavor?.name,
        },
      );
    }
    try {
      await probe();
      return SupportInfo.supported(
        details: <String, Object?>{'host': config.host, 'flavor': flavor?.name},
      );
    } on MissingPluginException catch (error) {
      return SupportInfo.unsupported(
        SupportState.unsupportedPlatform,
        message: 'Analytics is not implemented on this platform.',
        details: <String, Object?>{'error': '$error'},
      );
    } on UnsupportedError catch (error) {
      return SupportInfo.unsupported(
        SupportState.unsupportedPlatform,
        message: 'Analytics is not implemented on this platform.',
        details: <String, Object?>{'error': '$error'},
      );
    } on Failure catch (failure) {
      return SupportInfo.unsupported(
        failure.kind == FailureKind.configuration
            ? SupportState.notConfigured
            : SupportState.unavailable,
        message: failure.message,
        details: <String, Object?>{'code': failure.code.value},
      );
    } on Object catch (error) {
      return SupportInfo.unsupported(
        SupportState.unavailable,
        message: 'Analytics could not start: $error',
        details: <String, Object?>{'error': '$error'},
      );
    }
  }
}

# Changelog

## 0.1.0

- Rilis awal: controller locale dan penyimpanan pilihan lewat `Storage` bila
  tersedia.
- Terjemahan bersumber dari file ARB (`lib/l10n/app_<locale>.arb`) dan
  `flutter gen-l10n`; installer mengaktifkan `flutter.generate`.
- Resolusi locale regional seperti `id_ID` dipetakan ke `id`.
- Placeholder dan plural mengikuti aturan ARB/intl, bukan formatter sendiri.
- Format tanggal/angka/mata uang menurut locale, dan pesan ramah untuk setiap
  `FailureCode` dari ARB.
- Widget `LanguageSwitcher` dalam gaya dropdown dan segmented.

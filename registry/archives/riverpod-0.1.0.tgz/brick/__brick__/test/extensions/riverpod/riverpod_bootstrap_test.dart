import 'package:flutter_test/flutter_test.dart';
import 'package:kiln_core/kiln_core.dart';
import 'package:{{app_name}}/app/app.dart';
import 'package:{{app_name}}/core/l10n/app_strings.dart';
import 'package:{{app_name}}/extensions/riverpod/riverpod_module.dart';

void main() {
  testWidgets('application bootstraps with the riverpod wrapper', (
    tester,
  ) async {
    final registry = await KilnBootstrap.run(
      modules: const <KilnModule>[RiverpodModule()],
    );

    await tester.pumpWidget(KilnApp(registry: registry));
    await tester.pumpAndSettle();

    expect(find.text(AppStrings.readyTitle), findsOneWidget);
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:{{app_name}}/extensions/notifications/notifications_config.dart';

void main() {
  test('defaults carry the rendered prompts', () {
    const config = NotificationsConfig.defaults;

    expect(config.defaultChannelId, 'kiln_default');
    expect(config.smallIcon, '@mipmap/ic_launcher');
    expect(config.exactAlarms, isFalse);
  });
}

# Changelog

## 0.1.1

- Add `LoggerSupport` with file-sink and sink configuration details.
- When file logging is unavailable, report the degradation while the console,
  memory, and breadcrumb sinks keep working.

## 0.1.0

- Added `LoggerModule` along with `AppLogger`, per-flavor level configuration,
  and runtime level control.
- Added a sink pipeline, text and JSON lines formatters, PII redaction, a memory
  buffer, rotating log files, and crash breadcrumbs.
- Added a log exporter, HTTP middleware, and a debug log page.

import 'package:kiln_core/kiln_core.dart';

import 'biometric.dart';

/// [SecureStorage] that asks for biometrics before reading a value.
final class BiometricProtectedStorage implements SecureStorage {
  const BiometricProtectedStorage({
    required this.storage,
    required this.biometric,
  });

  final SecureStorage storage;
  final Biometric biometric;

  @override
  Future<String?> read(String key) async {
    await _authenticate();
    return storage.read(key);
  }

  @override
  Future<void> write(String key, String value) => storage.write(key, value);

  @override
  Future<void> delete(String key) => storage.delete(key);

  /// Authenticates once, then returns every protected value.
  @override
  Future<Map<String, String>> readAll() async {
    await _authenticate();
    return storage.readAll();
  }

  @override
  Future<void> clear() => storage.clear();

  Future<void> _authenticate() async {
    final authenticated = await biometric.authenticate();
    if (!authenticated) {
      throw const Failure(
        code: FailureCode.permissionDenied,
        message: 'Biometric authentication is required to read data.',
        kind: FailureKind.permission,
      );
    }
  }
}

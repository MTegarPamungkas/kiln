# Changelog

## 0.2.2

- Resolve relative request URIs against `DioConfig.baseUrl`; previously the
  configured base URL was ignored and relative paths reached the adapter
  unresolved.

## 0.2.1

- Dio failures are mapped to `Failure` inside the transport handler, so
  pipeline middleware such as `http_retry` can retry 5xx responses.

## 0.2.0

- Add typed configuration and pipeline middleware.
- Add request id and user agent interceptors.

## 0.1.0

- Initial release.

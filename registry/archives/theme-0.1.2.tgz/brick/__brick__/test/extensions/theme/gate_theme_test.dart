import 'package:material_ui/material_ui.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kiln_core/kiln_core.dart';
import 'package:{{app_name}}/extensions/theme/gate_theme.dart';
import 'package:{{app_name}}/extensions/theme/theme_mode_controller.dart';

void main() {
  test('gate switches the theme mode in one call', () async {
    final registry = GetItRegistry()
      ..registerSingleton<ThemeModeController>(
        ThemeModeController(initialMode: ThemeMode.light),
      );
    final gate = Gate(registry);

    expect(gate.themeMode, ThemeMode.light);

    final result = await gate.setThemeMode(ThemeMode.dark);

    expect(result, isA<Ok<PersistOutcome>>());
    expect(result.valueOrNull, PersistOutcome.notConfigured);
    expect(gate.themeMode, ThemeMode.dark);
  });
}
